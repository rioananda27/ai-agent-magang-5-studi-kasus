# Rancangan AI Agent untuk Lima Studi Kasus Magang

Repository ini menyajikan identifikasi aktivitas repetitif, rancangan AI Agent, workflow, contoh data dummy, dan rencana pengujian untuk **lima lingkungan magang**:

1. Administrasi perkantoran dinas pemerintahan daerah.
2. Klinik dokter, khusus registrasi dan pencatatan anamnesis terstruktur.
3. Digital marketing agency.
4. Perusahaan kelapa sawit, bagian HRD.
5. Bank, bagian administrasi kredit.

## Tujuan project

Mengidentifikasi pekerjaan yang berulang dan memiliki aturan jelas, kemudian merancang AI Agent yang dapat menyelesaikan satu tugas administratif dari input sampai output secara otomatis. Fokusnya bukan menggantikan seluruh profesi atau mengambil keputusan profesional.

## Isi repository

```text
ai-agent-magang-5-studi-kasus/
├── README.md
├── .gitignore
├── requirements-note.txt
├── docs/
│   ├── 01-identifikasi-lima-studi-kasus.md
│   ├── 02-kriteria-otomatisasi-100-persen.md
│   ├── 03-perbandingan-dan-prioritas.md
│   ├── 04-batasan-privasi-dan-kontrol.md
│   ├── 05-rencana-demo-dan-pengujian.md
│   └── 06-visualisasi-workflow.md
├── agents/
│   ├── administrasi-pemerintahan-agent.md
│   ├── klinik-registrasi-anamnesis-agent.md
│   ├── digital-marketing-agent.md
│   ├── hrd-perusahaan-sawit-agent.md
│   └── bank-administrasi-kredit-agent.md
├── workflows/
│   └── [5 file diagram Mermaid .mmd]
├── examples/
│   └── [5 file data dummy .csv/.json]
└── configs/
    └── agent-config.example.yaml
```

## Ringkasan lima rancangan Agent

| Studi kasus | AI Agent yang dirancang | Tugas utama |
|---|---|---|
| Administrasi pemerintahan | Government Office Administration Agent | Registrasi surat masuk, klasifikasi sesuai aturan, dan pengarsipan digital. |
| Klinik | Clinic Registration & Structured Intake Agent | Registrasi, penjadwalan, antrean, dan pencatatan jawaban anamnesis sesuai formulir. |
| Digital marketing | Digital Marketing Operations Agent | Pengumpulan metrik dan penyusunan laporan performa berkala. |
| HRD perusahaan sawit | Plantation HR Attendance Agent | Rekonsiliasi absensi dan rekap jam kerja berdasarkan formula resmi. |
| Bank bagian kredit | Bank Credit Administration Agent | Checklist kelengkapan dan ekstraksi data administratif berkas kredit. |

## Arti “otomatis 100%” dalam project ini

Istilah 100% dibatasi pada **satu tugas rutin dengan ruang lingkup, input, SOP, dan output yang jelas**. Agent dapat menjalankan seluruh langkah normal tanpa operator mengerjakan langkah rutin di tengah proses. Jika input tidak lengkap, data ambigu, atau sistem gagal, Agent harus berhenti pada status aman dan mencatat/menyerahkan pengecualian. Hal ini tidak berarti seluruh pekerjaan suatu jabatan dapat dilakukan tanpa manusia.

## Mulai membaca

1. Buka [identifikasi jobdesk lima studi kasus](docs/01-identifikasi-lima-studi-kasus.md).
2. Baca [kriteria otomatisasi 100%](docs/02-kriteria-otomatisasi-100-persen.md).
3. Lihat [perbandingan dan prioritas](docs/03-perbandingan-dan-prioritas.md).
4. Pelajari spesifikasi masing-masing Agent di folder `agents/`.
5. Lihat diagram di [visualisasi workflow](docs/06-visualisasi-workflow.md).
6. Gunakan [rencana demo dan pengujian](docs/05-rencana-demo-dan-pengujian.md) bersama data di folder `examples/`.

## Cara mengunggah ke GitHub

1. Unduh ZIP dan ekstrak ke komputer.
2. Buka [GitHub](https://github.com/) dan buat repository baru.
3. Unggah **seluruh isi folder project**, bukan file ZIP-nya saja. Bisa menggunakan tombol **Add file → Upload files** atau GitHub Desktop.
4. Pastikan `README.md`, `docs/`, `agents/`, `workflows/`, `examples/`, dan `configs/` tampil di repository.
5. Salin tautan repository untuk dikumpulkan.

## Status implementasi

Ini adalah **rancangan dan paket dokumentasi dengan contoh data uji**, bukan lima aplikasi AI Agent yang sudah terhubung ke sistem nyata. API, autentikasi, database, eksekusi workflow, dan deployment belum diimplementasikan. Folder `examples/` hanya berisi data sintetis untuk membantu demonstrasi dan pengembangan berikutnya.

## Privasi dan keselamatan

- Gunakan hanya data dummy untuk tugas dan repository publik.
- Jangan mengunggah data pasien, nasabah, pegawai, surat internal, atau data klien sungguhan.
- Jangan menyimpan token, password, API key, atau kredensial di GitHub.
- Keputusan klinis, keputusan kredit, keputusan kepegawaian, persetujuan pejabat, dan strategi pemasaran tetap berada pada pihak berwenang.
