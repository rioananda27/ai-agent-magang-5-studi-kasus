# 1. Identifikasi Jobdesk dan Aktivitas Repetitif pada Lima Studi Kasus

## Definisi ruang lingkup

Daftar berikut hanya memasukkan tugas yang hasil operasionalnya dapat diselesaikan Agent secara otomatis apabila aturan, data, dan integrasi telah tersedia. Persetujuan, tanda tangan, diagnosis, keputusan kepegawaian, keputusan kredit, dan penilaian strategis tidak dianggap sebagai tugas otomatis penuh.

## Studi Kasus 1 — Administrasi Perkantoran Dinas Pemerintahan Daerah

| Jobdesk | Aktivitas yang dapat diotomatisasi penuh | Output |
|---|---|---|
| Registrasi surat masuk | Membaca file surat, mengekstrak nomor/tanggal/pengirim/perihal, memberi kategori sesuai daftar baku, lalu mencatat ke register persuratan | Entri register surat masuk |
| Pengarsipan digital | Membaca metadata dokumen, memberi nama file sesuai standar, mengelompokkan berdasarkan unit/tahun/jenis, dan menyimpan ke folder atau DMS yang ditentukan | Arsip digital terindeks |
| Distribusi surat administratif | Mengarahkan surat ke unit tujuan berdasarkan matriks klasifikasi dan aturan routing yang sudah ditetapkan | Surat diteruskan ke antrean unit terkait |
| Penjadwalan rapat rutin | Memeriksa kalender yang terhubung, memilih slot yang memenuhi aturan, membuat undangan, dan mengirim pengingat | Undangan dan pengingat rapat |
| Notulensi berbasis rekaman/transkrip | Mengubah rekaman/transkrip rapat menjadi ringkasan, daftar topik, keputusan yang disebutkan, serta daftar tindak lanjut | Draf notulen terstruktur |
| Pelaporan administrasi berkala | Mengambil data register, menghitung jumlah surat per kategori/periode, dan membuat rekap | Laporan administrasi berkala |

**Tidak dimasukkan sebagai otomatisasi penuh:** menandatangani surat dinas, menetapkan kebijakan, memberi disposisi substantif pejabat, memutuskan perkara kepegawaian, atau menyetujui dokumen resmi.

## Studi Kasus 2 — Klinik Dokter: Registrasi dan Anamnesis

| Jobdesk | Aktivitas yang dapat diotomatisasi penuh | Output |
|---|---|---|
| Penjadwalan pasien | Memeriksa slot praktik dari sistem, membuat/mengubah/membatalkan janji, lalu mengirim konfirmasi dan pengingat | Jadwal kunjungan pasien |
| Registrasi administratif | Mengumpulkan data identitas dan kontak melalui formulir, memeriksa kolom wajib dan format data, mencari kemungkinan data duplikat, lalu membuat entri kunjungan | Data registrasi terstruktur |
| Pengelolaan antrean | Membuat nomor antrean berdasarkan urutan dan jenis layanan sesuai aturan, memperbarui status antrean, dan mengirim pemberitahuan | Nomor serta status antrean |
| Pengumpulan jawaban anamnesis terstruktur | Mengajukan pertanyaan sesuai formulir yang disusun/ditetapkan klinik, merekam jawaban pasien, lalu memetakan jawaban ke kolom yang tepat tanpa menafsirkan diagnosis | Formulir anamnesis terisi |
| Transkripsi jawaban pasien | Mengubah jawaban suara menjadi teks, memberi penanda bila bagian tidak terdengar, dan menghubungkan teks ke pertanyaan terkait | Transkrip anamnesis |
| Instruksi pra-kunjungan | Mengirim informasi administratif dari template resmi, seperti jam kedatangan, lokasi, dan dokumen yang perlu dibawa | Pesan informasi pasien |

**Batas tegas:** Agent tidak mendiagnosis, menentukan tingkat kegawatan, menyarankan obat, mengubah jawaban pasien menjadi kesimpulan klinis, atau menggantikan dokter. Data kesehatan harus diproses dengan persetujuan, pembatasan akses, keamanan, dan kebijakan retensi yang sesuai.

## Studi Kasus 3 — Digital Marketing Agency

| Jobdesk | Aktivitas yang dapat diotomatisasi penuh | Output |
|---|---|---|
| Social media scheduling | Mengambil materi yang sudah berstatus disetujui, memeriksa slot kalender, menjadwalkan dan memublikasikan melalui integrasi resmi | Konten terbit sesuai jadwal |
| Social media monitoring | Mengambil metrik dan interaksi dari platform melalui API yang tersedia, lalu menyimpannya ke basis data | Dataset performa media sosial |
| Social media reporting | Menghitung metrik sesuai rumus yang ditentukan, membandingkan periode, membuat grafik dan laporan, lalu mengirimkannya | Laporan performa |
| SEO technical audit | Crawling halaman yang diizinkan, memeriksa status HTTP, tautan rusak, title, meta description, sitemap, dan robots.txt | Laporan audit teknis |
| Competitor website monitoring | Memantau halaman publik yang ditentukan, membandingkan versi terbaru dengan snapshot sebelumnya, dan melaporkan perubahan | Log perubahan kompetitor |
| UTM link generation | Membuat parameter UTM dari input kampanye menggunakan aturan penamaan baku dan memvalidasi URL | Link kampanye ber-UTM |
| Content repurposing terstandar | Mengubah materi sumber yang telah disetujui ke format teks dan batas karakter platform berdasarkan template | Variasi teks per platform |

**Tidak dimasukkan sebagai otomatisasi penuh:** menetapkan strategi merek, menyetujui klaim iklan, menentukan anggaran, atau memublikasikan materi yang belum disetujui klien.

## Studi Kasus 4 — Perusahaan Kelapa Sawit: HRD

| Jobdesk | Aktivitas yang dapat diotomatisasi penuh | Output |
|---|---|---|
| Rekonsiliasi absensi | Mengimpor data mesin absensi, mencocokkan ID karyawan dan jadwal kerja, menghitung jam hadir/terlambat berdasarkan aturan, dan menandai data tidak lengkap | Rekap absensi |
| Perhitungan jam kerja | Menghitung jam kerja reguler dan lembur berdasarkan jadwal serta formula yang telah ditetapkan; hasil anomali dipisahkan | Rekap jam kerja dan lembur |
| Pengarsipan dokumen karyawan | Mengekstrak metadata dokumen, mengategorikan, memberi nama file, dan menyimpan ke folder digital dengan hak akses yang ditentukan | Arsip personalia |
| Pengingat masa berlaku dokumen | Memeriksa tanggal berakhir dokumen yang tercatat dan mengirim pengingat pada interval yang ditentukan | Notifikasi masa berlaku |
| Penjadwalan wawancara | Mencocokkan slot kalender pewawancara yang terhubung dengan ketersediaan kandidat, mengirim undangan dan pengingat | Jadwal wawancara |
| Rekap pelatihan | Mengumpulkan kehadiran dan hasil penyelesaian pelatihan dari sistem, lalu menerbitkan rekap atau sertifikat otomatis sesuai syarat | Laporan pelatihan/sertifikat |
| Laporan tenaga kerja berkala | Menghitung jumlah karyawan per unit/lokasi/status berdasarkan data HRIS dan membuat laporan | Laporan headcount |

**Tidak dimasukkan sebagai otomatisasi penuh:** memutuskan perekrutan/pemecatan, menilai karakter pekerja, menjatuhkan sanksi, menyetujui lembur khusus, atau menetapkan upah/benefit di luar formula resmi.

## Studi Kasus 5 — Bank: Bagian Kredit

| Jobdesk | Aktivitas yang dapat diotomatisasi penuh | Output |
|---|---|---|
| Pemeriksaan kelengkapan dokumen | Membaca daftar periksa produk kredit, mencocokkan dokumen yang diterima, mengidentifikasi dokumen yang belum ada/kedaluwarsa, dan membuat status kelengkapan | Checklist dokumen |
| Ekstraksi data dokumen | Mengambil field tertentu dari dokumen yang diizinkan, menyimpan sumber halaman, dan menandai teks yang tidak terbaca | Data aplikasi hasil ekstraksi |
| Validasi administratif | Memeriksa format tanggal, nomor, kolom wajib, dan konsistensi antar-field sesuai aturan deterministik | Daftar hasil validasi |
| Simulasi angsuran | Menghitung estimasi cicilan berdasarkan formula, suku bunga, tenor, dan input produk yang berlaku; menampilkan asumsi perhitungan | Hasil simulasi |
| Pengingat kekurangan dokumen | Mengirim pemberitahuan berbasis template kepada pemohon mengenai dokumen yang belum diterima | Notifikasi kelengkapan |
| Pembaruan status administratif | Mengambil status dari sistem kredit dan mengirim notifikasi status yang telah ditetapkan oleh sistem sumber | Informasi status aplikasi |
| Penyusunan bundel berkas | Menggabungkan dokumen sesuai urutan checklist, membuat indeks, dan menyiapkan paket digital untuk proses berikutnya | Bundel berkas kredit |

**Batas tegas:** Agent tidak menyetujui/menolak kredit, menetapkan limit, memutuskan kelayakan pemohon, mengubah data sumber, atau membuat rekomendasi final kelayakan. Penilaian kredit tetap mengikuti proses dan otorisasi bank.

## Ringkasan

Kelima studi kasus memiliki peluang otomatisasi kuat pada tugas yang terstruktur, berulang, berbasis data, dan memiliki aturan eksplisit. Perbedaan utama terletak pada batasan data dan risiko: data kesehatan di klinik, data kepegawaian di HRD, dokumen pemerintahan, data pemasaran klien, serta data finansial di bank memerlukan akses terbatas dan jejak audit.
