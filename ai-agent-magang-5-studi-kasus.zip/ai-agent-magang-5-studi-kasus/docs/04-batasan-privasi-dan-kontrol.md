# 4. Privasi, Keamanan, dan Kontrol

## Prinsip umum

- Gunakan data dummy untuk tugas kuliah dan demonstrasi.
- Jangan mengunggah identitas pasien, nasabah, karyawan, dokumen dinas internal, atau data klien ke repository publik.
- Simpan API key, token, kata sandi, dan kredensial di secret manager atau environment variable, bukan di GitHub.
- Berikan hak akses minimum sesuai fungsi Agent.
- Catat waktu proses, sumber data, tindakan yang dilakukan, dan hasilnya (audit log).
- Tetapkan masa retensi dan prosedur penghapusan data.
- Gunakan API/konektor resmi dan patuhi izin akses dari pemilik sistem.

## Batas sesuai bidang

### Pemerintahan
Agent dapat mencatat, mengklasifikasikan, mengarsipkan, dan mengarahkan surat sesuai aturan. Agent tidak menandatangani atau membuat keputusan pejabat.

### Klinik
Agent dapat membantu registrasi dan merekam jawaban pasien secara terstruktur. Agent tidak mendiagnosis, melakukan triase klinis, atau memberi terapi. Data kesehatan hanya diproses melalui sistem yang disetujui klinik dengan pengamanan dan persetujuan yang sesuai.

### Digital marketing
Gunakan akses akun yang diberikan secara resmi. Publikasi otomatis hanya untuk materi yang status persetujuannya sudah jelas. Hindari mengambil data pribadi audiens tanpa dasar dan izin yang sesuai.

### HRD perusahaan sawit
Gunakan data absensi dan karyawan hanya untuk tujuan HR yang ditentukan. Hasil perhitungan yang memengaruhi pengupahan harus dapat ditelusuri ke sumber data dan aturan formula.

### Bank
Agent dapat memeriksa kelengkapan dan mengekstrak data administratif. Keputusan kredit, limit, dan persetujuan tetap di luar ruang lingkup Agent pada rancangan ini.

## Mekanisme aman saat terjadi masalah

Jika Agent menemukan data tidak terbaca, identitas tidak cocok, sumber tidak tersedia, atau ada konflik aturan, Agent harus:

1. Tidak menebak atau mengarang data.
2. Tidak melakukan tindakan final yang berisiko.
3. Menyimpan status gagal/tertunda dan alasan yang spesifik.
4. Mengirim kasus ke petugas berwenang melalui jalur eskalasi.
