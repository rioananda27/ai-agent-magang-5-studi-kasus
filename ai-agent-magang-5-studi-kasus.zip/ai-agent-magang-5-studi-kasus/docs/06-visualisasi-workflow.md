# 6. Visualisasi Workflow Lima AI Agent

GitHub dapat merender diagram Mermaid dari blok kode di file Markdown. File sumber `.mmd` asli juga disimpan pada folder `workflows/`.

## Administrasi pemerintahan

```mermaid
flowchart TD
 A[Surat digital masuk] --> B[Ekstrak metadata]
 B --> C{Field wajib lengkap?}
 C -->|Ya| D[Klasifikasikan sesuai daftar baku]
 C -->|Tidak| E[Catat kekurangan dan eskalasi]
 D --> F[Catat ke register]
 F --> G[Arsipkan sesuai aturan nama/folder]
 G --> H[Kirim notifikasi dan simpan log]
```

## Klinik: registrasi dan anamnesis

```mermaid
flowchart TD
 A[Pasien memulai pendaftaran] --> B[Pilih jadwal]
 B --> C[Validasi data registrasi]
 C --> D{Data administratif valid?}
 D -->|Tidak| E[Minta pasien melengkapi data]
 E --> C
 D -->|Ya| F[Buat catatan kunjungan]
 F --> G[Ajukan pertanyaan sesuai formulir klinik]
 G --> H[Catat atau transkripsikan jawaban]
 H --> I[Tandai jawaban kosong/tidak jelas]
 I --> J[Buat antrean dan kirim konfirmasi]
 J --> K[Formulir terstruktur tersedia untuk tenaga kesehatan]
```

## Digital marketing agency

```mermaid
flowchart TD
 A[Jadwal laporan tiba] --> B[Ambil data melalui API resmi]
 B --> C{Data tersedia dan valid?}
 C -->|Tidak| D[Catat error dan sumber yang gagal]
 C -->|Ya| E[Hitung KPI sesuai formula]
 E --> F[Bandingkan periode]
 F --> G[Buat tabel dan grafik]
 G --> H[Ekspor laporan]
 H --> I[Kirim ke penerima yang ditetapkan]
```

## HRD perusahaan sawit

```mermaid
flowchart TD
 A[File absensi tersedia] --> B[Impor dan validasi format]
 B --> C[Cocokkan ID karyawan dan shift]
 C --> D{Data cocok dan lengkap?}
 D -->|Tidak| E[Masukkan ke daftar anomali]
 D -->|Ya| F[Hitung jam kerja sesuai aturan]
 F --> G[Susun rekap per karyawan dan unit]
 E --> H[Gabungkan hasil dan anomali]
 G --> H
 H --> I[Simpan laporan dan kirim notifikasi]
```

## Bank: administrasi kredit

```mermaid
flowchart TD
 A[Dokumen aplikasi diterima] --> B[Identifikasi dan ekstrak dokumen]
 B --> C[Cocokkan dengan checklist]
 C --> D{Dokumen administratif lengkap?}
 D -->|Tidak| E[Buat daftar kekurangan]
 E --> F[Kirim notifikasi administratif]
 D -->|Ya| G[Validasi field dan konsistensi format]
 G --> H[Susun bundel berkas dan indeks]
 F --> I[Simpan status dan audit log]
 H --> I
 I --> J[Teruskan ke proses penilaian kredit oleh pihak berwenang]
```
