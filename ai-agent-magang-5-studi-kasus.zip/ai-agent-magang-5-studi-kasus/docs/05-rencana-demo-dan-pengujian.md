# 5. Rencana Demonstrasi dan Pengujian untuk Lima AI Agent

Dokumen ini menjadi panduan bila rancangan akan dipresentasikan atau dikembangkan menjadi prototipe. Semua contoh pada folder `examples/` adalah data fiktif. Jangan menggantinya dengan data pasien, pegawai, nasabah, surat dinas, atau klien yang sebenarnya untuk demonstrasi kelas.

## 1. Administrasi pemerintahan: registrasi surat

- **Pemicu:** file surat baru masuk ke folder uji.
- **Input:** `examples/administrasi-surat-demo.csv`, daftar kategori surat, unit tujuan, dan aturan penamaan arsip.
- **Proses:** validasi metadata, cek duplikasi nomor surat, klasifikasi sesuai daftar baku, buat nomor register, simpan file pada folder yang ditentukan, dan catat log.
- **Output yang diharapkan:** register surat dan metadata arsip.
- **Kriteria lulus:** semua kolom yang tersedia tercatat; nomor duplikat ditandai; surat dengan metadata wajib yang hilang tidak diklasifikasikan secara spekulatif.

## 2. Klinik: registrasi dan pencatatan anamnesis terstruktur

- **Pemicu:** pasien demo mengirim formulir pendaftaran.
- **Input:** `examples/klinik-registrasi-anamnesis-demo.json`, slot jadwal contoh, daftar pertanyaan dan aturan wajib isi yang telah ditetapkan klinik.
- **Proses:** validasi kolom registrasi, buat catatan kunjungan, catat jawaban pada kolom yang sesuai, tandai jawaban kosong/tidak jelas, lalu buat konfirmasi dan nomor antrean simulasi.
- **Output yang diharapkan:** data registrasi dan formulir jawaban terstruktur.
- **Kriteria lulus:** jawaban disalin tanpa ditafsirkan sebagai diagnosis; data yang tidak diberikan tetap ditandai kosong; tidak ada rekomendasi obat atau triase klinis.

## 3. Digital marketing agency: social media reporting

- **Pemicu:** jadwal laporan harian atau mingguan.
- **Input:** `examples/digital-marketing-metrics-demo.csv`, definisi KPI, periode laporan, dan template.
- **Proses:** validasi angka dan periode, hitung total metrik, hitung engagement rate dengan formula yang telah ditentukan agency, bandingkan periode, lalu ekspor laporan.
- **Formula contoh:** engagement rate by reach = `(likes + comments + shares + saves) / reach × 100%`. Formula dapat berbeda antarplatform atau agency; gunakan definisi yang disepakati.
- **Output yang diharapkan:** tabel ringkasan dan laporan performa.
- **Kriteria lulus:** angka laporan dapat ditelusuri ke baris sumber; pembagian dengan reach nol ditangani sebagai nilai tidak tersedia, bukan angka rekaan.

## 4. HRD perusahaan sawit: rekonsiliasi absensi

- **Pemicu:** file absensi periode kerja tersedia.
- **Input:** `examples/hrd-absensi-demo.csv`, master kode karyawan, jadwal/shift, kalender kerja, dan formula resmi perusahaan.
- **Proses:** validasi ID dan format waktu, cocokkan dengan shift, hitung keterlambatan dan durasi kerja berdasarkan formula, tandai clock-in/clock-out yang hilang, lalu buat rekap.
- **Asumsi demo:** durasi kerja bersih = selisih clock-out dan clock-in dikurangi waktu istirahat pada kolom `break_minutes`. Ini hanya formula ilustratif, bukan aturan ketenagakerjaan atau kebijakan perusahaan.
- **Output yang diharapkan:** rekap per kode karyawan dan daftar anomali.
- **Kriteria lulus:** data yang tidak lengkap masuk daftar anomali; Agent tidak mengarang jam masuk/keluar dan tidak menetapkan sanksi atau upah.

## 5. Bank: pemeriksaan administratif dokumen kredit

- **Pemicu:** berkas aplikasi kredit demo diterima.
- **Input:** `examples/bank-checklist-kredit-demo.json`, checklist produk kredit, dan aturan pemeriksaan format.
- **Proses:** identifikasi dokumen, cocokkan checklist, tandai dokumen yang tidak diterima atau tidak terbaca, susun daftar kekurangan, dan siapkan bundel berkas.
- **Output yang diharapkan:** checklist kelengkapan dan daftar dokumen yang perlu dilengkapi/diperiksa ulang.
- **Kriteria lulus:** dokumen yang tidak terbaca tidak dianggap valid; Agent tidak menghitung skor kelayakan dan tidak menyetujui atau menolak kredit.

## Pengujian umum untuk semua Agent

| Skenario uji | Perilaku yang diharapkan |
|---|---|
| Input valid dan lengkap | Agent menyelesaikan alur rutin dan menyimpan output serta log. |
| Ada kolom wajib kosong | Agent menandai kekurangan; tidak mengisi dengan tebakan. |
| Data duplikat | Agent mendeteksi dan mencegah pencatatan ganda sesuai aturan. |
| Format tidak dikenali | Agent menghentikan pemrosesan item terkait dan mencatat alasan. |
| Integrasi/sumber data gagal | Agent mencatat kegagalan dan tidak membuat angka atau dokumen fiktif. |
| Permintaan di luar ruang lingkup | Agent menolak tindakan tersebut dan memberi status eskalasi. |

## Definisi keberhasilan

Prototipe dinyatakan berhasil apabila dapat memproses kasus normal menggunakan data dummy, menghasilkan output yang sesuai format, menjaga jejak sumber data, dan berhenti dengan aman ketika menemui kasus di luar aturan. Pengujian dengan data dummy tidak membuktikan sistem siap digunakan pada lingkungan produksi.
