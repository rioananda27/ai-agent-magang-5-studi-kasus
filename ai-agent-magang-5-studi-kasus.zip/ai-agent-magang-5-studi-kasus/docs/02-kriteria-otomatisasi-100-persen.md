# 2. Kriteria Aktivitas yang Benar-Benar Dapat Dikerjakan 100% oleh AI Agent

## Definisi operasional

Satu aktivitas dinilai dapat diotomatisasi 100% apabila Agent mampu menyelesaikan seluruh langkah rutin dalam batas tugas yang sudah ditentukan: menerima pemicu, mengambil input, memvalidasi, memproses, melakukan tindakan pada sistem tujuan, dan menyimpan hasil/log. Tidak boleh ada langkah manual rutin yang menjadi syarat penyelesaian.

## Lima syarat wajib

1. **Input tersedia:** dokumen, data, atau pesan dapat diterima secara digital dan sah diakses.
2. **SOP eksplisit:** kategori, formula, format, jadwal, dan kondisi pengecualian ditulis dengan jelas.
3. **Integrasi tersedia:** Agent mempunyai API, konektor, atau akses sistem yang diizinkan untuk membaca dan menulis data.
4. **Output dapat dieksekusi:** hasil dapat disimpan, dikirim, dijadwalkan, atau diperbarui secara otomatis.
5. **Penanganan kegagalan terdefinisi:** jika data hilang, konflik, atau sistem gagal, Agent berhenti pada status aman, mencatat penyebab, dan mengirim eskalasi. Eskalasi bukan bagian dari penyelesaian tugas rutin; kasus pengecualian tidak boleh dipaksakan selesai otomatis.

## Contoh batas tugas

- Tepat: “Impor data absensi harian, cocokkan dengan jadwal, hitung total jam memakai formula yang diberikan, lalu simpan rekap.”
- Terlalu luas: “Kelola seluruh HRD perusahaan.”
- Tepat: “Periksa kelengkapan dokumen berdasarkan checklist kredit produk X dan kirim daftar kekurangan.”
- Terlalu berisiko: “Tentukan siapa yang layak menerima kredit.”
- Tepat: “Catat jawaban pasien pada formulir anamnesis sesuai pertanyaan yang telah ditetapkan.”
- Tidak tepat: “Diagnosis penyakit pasien dari anamnesis.”

## Tingkat otomatisasi yang digunakan dalam tugas

| Kategori | Arti | Perlakuan |
|---|---|---|
| Otomatis penuh dalam lingkup tugas | Agent menyelesaikan seluruh proses rutin dari input hingga output | Masuk daftar kandidat |
| Otomatis dengan eskalasi pengecualian | Kasus normal selesai otomatis; kasus ambigu/error diteruskan ke petugas | Masuk dengan catatan batasan |
| Membutuhkan keputusan profesional | Ada keputusan klinis, hukum, kepegawaian, finansial, atau strategis | Tidak diklaim sebagai 100% otomatis |

## Catatan penting

Otomatisasi penuh pada tugas administratif tidak sama dengan mengotomatisasi seluruh jabatan. Manusia tetap menetapkan kebijakan, memberi otorisasi, menangani pengecualian, dan bertanggung jawab atas keputusan yang berdampak besar.
