# 3. Perbandingan dan Prioritas Implementasi

| Studi kasus | Contoh tugas otomatis yang paling jelas | Data/sistem yang dibutuhkan | Risiko utama |
|---|---|---|---|
| Administrasi pemerintahan | Registrasi surat dan pengarsipan digital | Email/sistem persuratan, DMS, klasifikasi surat | Salah klasifikasi, dokumen rahasia |
| Klinik | Registrasi administratif dan penjadwalan pasien | Sistem klinik, kalender, formulir registrasi/anamnesis | Privasi dan keamanan data kesehatan |
| Digital marketing | Pelaporan media sosial dan audit teknis SEO | API platform, analytics, crawler, penyimpanan data | Akses akun klien, ketepatan metrik |
| HRD sawit | Rekonsiliasi absensi dan rekap jam kerja | Ekspor mesin absensi, jadwal kerja, HRIS | Kesalahan hitung berdampak pada hak pekerja |
| Bank kredit | Checklist dokumen dan ekstraksi data aplikasi | LOS/DMS, checklist produk, OCR, sistem notifikasi | Kerahasiaan data finansial dan kesalahan ekstraksi |

## Rekomendasi jika harus memilih satu

- **Paling mudah dijelaskan dan didemonstrasikan:** Digital Marketing Agency, melalui Social Media Reporting Agent atau UTM Generator.
- **Paling jelas proses administratifnya:** Administrasi pemerintahan, melalui registrasi surat dan pengarsipan digital.
- **Paling mudah dibuat dengan data contoh:** HRD perusahaan sawit, melalui rekonsiliasi absensi dari file CSV.
- **Perlu kehati-hatian ekstra:** Klinik dan bank, karena data sensitif dan konsekuensi kesalahan lebih tinggi.

## Rekomendasi proyek untuk demonstrasi kelas

Jika dosen meminta agent yang benar-benar bisa diuji tanpa akses sistem perusahaan, pilih simulasi **HRD - Rekonsiliasi Absensi** atau **Digital Marketing - UTM Link Generator/Reporting dari dataset contoh**. Buat dataset dummy, tetapkan aturan yang jelas, jalankan workflow, dan tampilkan output. Jangan menggunakan data karyawan, pasien, nasabah, atau klien yang asli.
