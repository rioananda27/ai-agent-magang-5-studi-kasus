# Digital Marketing Operations Agent

## Tujuan
Mengotomatisasi pengumpulan metrik media sosial dan penyusunan laporan performa berkala dari sumber data yang terhubung secara resmi.

## Input
- Akun/platform yang telah memberi otorisasi.
- Periode laporan.
- Definisi metrik dan formula yang digunakan agency.
- Template laporan dan daftar penerima.

## Proses
1. Menjalankan pengambilan data terjadwal melalui API.
2. Memvalidasi periode, kelengkapan, dan duplikasi data.
3. Menghitung KPI sesuai formula yang disepakati.
4. Membandingkan hasil dengan periode sebelumnya.
5. Membuat tabel dan grafik.
6. Menghasilkan laporan dan mengirimkannya ke lokasi/penerima yang telah ditetapkan.

## Output
Laporan performa media sosial beserta data sumber dan log waktu pengambilan.

## Batasan
Tidak mengubah anggaran iklan, menetapkan strategi, atau memublikasikan materi yang belum mendapat persetujuan. Jika API gagal, Agent mencatat data yang tidak tersedia dan tidak mengarang angka.

## Metrik
Keberhasilan pengambilan data, waktu pembuatan laporan, kelengkapan metrik, dan jumlah error integrasi.
