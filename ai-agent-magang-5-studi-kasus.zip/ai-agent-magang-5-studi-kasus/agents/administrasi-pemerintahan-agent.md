# Government Office Administration Agent

## Tujuan
Mengotomatisasi registrasi surat masuk dan pengarsipan digital berdasarkan klasifikasi serta standar penamaan yang ditetapkan instansi.

## Input
- File surat digital.
- Daftar kategori dan unit tujuan.
- Aturan penamaan file dan metadata wajib.
- Akses resmi ke sistem persuratan atau penyimpanan dokumen.

## Proses
1. Mendeteksi dokumen baru pada folder/inbox yang ditentukan.
2. Mengekstrak metadata seperti nomor, tanggal, pengirim, perihal, dan lampiran.
3. Memvalidasi field wajib dan format tanggal/nomor.
4. Mengklasifikasikan dokumen dengan daftar kategori baku.
5. Mencatat metadata ke register.
6. Menyimpan dokumen menggunakan pola nama dan folder yang ditentukan.
7. Mengirim notifikasi jika dokumen berhasil dicatat atau perlu pemeriksaan karena data tidak terbaca.

## Output
Entri register, file terarsip, metadata pencarian, dan log proses.

## Batasan
Tidak menandatangani surat, membuat disposisi substantif, atau mengambil keputusan pejabat. Kasus klasifikasi yang tidak pasti dieskalasikan.

## Metrik
Jumlah surat diproses, persentase field berhasil diekstrak, duplikasi terdeteksi, dan jumlah kasus eskalasi.
