# Clinic Registration & Structured Intake Agent

## Tujuan
Mengotomatisasi proses administratif pendaftaran, antrean, penjadwalan, dan pencatatan jawaban pasien ke formulir anamnesis yang telah ditentukan klinik.

## Input
- Slot praktik yang tersedia.
- Formulir registrasi dan daftar pertanyaan anamnesis yang disetujui klinik.
- Data yang diberikan pasien.
- Akses resmi ke sistem klinik.

## Proses
1. Menampilkan slot jadwal dan mencatat pilihan pasien.
2. Mengumpulkan data registrasi dan memvalidasi kelengkapan/format.
3. Membuat atau memperbarui catatan kunjungan sesuai aturan identifikasi pasien.
4. Mengajukan pertanyaan sesuai urutan formulir yang ditetapkan klinik.
5. Menyalin jawaban teks atau mentranskripsikan suara ke kolom terkait.
6. Menandai jawaban kosong atau transkrip yang tidak jelas tanpa menafsirkannya.
7. Membuat nomor antrean dan mengirim konfirmasi administratif.

## Output
Data registrasi, jadwal, nomor antrean, dan formulir anamnesis terstruktur untuk ditinjau tenaga kesehatan.

## Batasan
Tidak melakukan diagnosis, triase, penentuan kegawatan, rekomendasi obat, atau interpretasi klinis. Data kesehatan memerlukan persetujuan, kontrol akses, keamanan penyimpanan, dan kebijakan retensi.

## Metrik
Waktu registrasi, kelengkapan field administratif, tingkat duplikasi, dan jumlah jawaban yang perlu klarifikasi.
