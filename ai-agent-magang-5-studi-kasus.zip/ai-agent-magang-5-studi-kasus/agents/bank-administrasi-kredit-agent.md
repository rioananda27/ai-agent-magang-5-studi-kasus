# Bank Credit Administration Agent

## Tujuan
Mengotomatisasi pemeriksaan kelengkapan dokumen dan ekstraksi data administratif aplikasi kredit berdasarkan checklist produk yang berlaku.

## Input
- Dokumen aplikasi yang diserahkan melalui kanal resmi.
- Checklist dokumen untuk produk kredit terkait.
- Aturan validasi field administratif.
- Akses resmi ke document management system/loan origination system.

## Proses
1. Mendeteksi aplikasi atau dokumen baru.
2. Mengidentifikasi jenis dokumen.
3. Mengekstrak field yang dibutuhkan dan mencatat referensi sumber/halaman.
4. Mencocokkan dokumen dengan checklist.
5. Memeriksa format dan konsistensi administratif sesuai aturan deterministik.
6. Membuat daftar dokumen kurang/tidak terbaca.
7. Mengirim pemberitahuan administratif berbasis template atau menyiapkan bundel digital.

## Output
Checklist kelengkapan, hasil ekstraksi, daftar kekurangan, bundel berkas, dan audit log.

## Batasan
Tidak menyetujui/menolak kredit, menentukan limit, menetapkan kelayakan, atau memberi rekomendasi final. Keputusan kredit tetap mengikuti proses otorisasi bank.

## Metrik
Akurasi ekstraksi yang diuji, dokumen terklasifikasi, kelengkapan checklist, dan kasus eskalasi.
