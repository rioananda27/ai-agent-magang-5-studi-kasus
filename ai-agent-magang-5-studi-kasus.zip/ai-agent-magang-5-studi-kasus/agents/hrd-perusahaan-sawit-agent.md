# Plantation HR Attendance Agent

## Tujuan
Mengotomatisasi rekonsiliasi data absensi dan pembuatan rekap jam kerja berdasarkan jadwal serta formula HR yang telah ditetapkan.

## Input
- Ekspor data mesin absensi.
- Master karyawan dan lokasi/unit kerja.
- Jadwal/shift.
- Aturan perhitungan jam kerja dan format laporan.

## Proses
1. Mengimpor file absensi pada jadwal tertentu.
2. Memvalidasi format dan ID karyawan.
3. Mencocokkan waktu masuk/keluar dengan jadwal kerja.
4. Menghitung kehadiran, keterlambatan, dan jam kerja menggunakan formula yang disediakan.
5. Menandai data hilang, bentrok, atau tidak wajar.
6. Menghasilkan rekap per karyawan, unit, dan periode.
7. Menyimpan laporan dan mengirim notifikasi untuk kasus pengecualian.

## Output
Rekap absensi dan jam kerja, daftar anomali, serta log pemrosesan.

## Batasan
Tidak memutuskan sanksi, pemecatan, penerimaan, atau perubahan upah. Perhitungan yang menjadi dasar pembayaran harus dapat diaudit dan diverifikasi sesuai prosedur perusahaan.

## Metrik
Jumlah baris diproses, persentase kecocokan ID, anomali terdeteksi, dan ketepatan waktu laporan.
